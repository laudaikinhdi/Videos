<template>
	<Page class="page">
		<ActionBar title="Data" class="action-bar" />
		<StackLayout class="home-panel">
			<Button class="btn btn-success" @tap="goBack" text="Back" />
			<TextField v-model="search" hint="Search..." />
			<ListView class="list-group" for="country in computedSearch" @itemTap="onItemTap" style="height:1250px">
				<v-template>
					<FlexboxLayout flexDirection="row" class="list-group-item">
						<Label :text="country.name + ' - ' + country.email" class="list-group-item-heading" style="width: 60%" />
					</FlexboxLayout>
				</v-template>
			</ListView>
		</StackLayout>
	</Page>
</template>
<script>
export default {
    props: {
        countries:{
            type: Array,
            required: true
        }
    },
    computed: {
        computedSearch() {
            return this.countries.filter(data => {
                return data.email
                    .toLowerCase()
                    .includes(this.search.toLowerCase());
            });
        }
    },
    methods: {
        goBack() {
            this.$navigateBack();
        }
    },
    data() {
        return {
            search: "",

            screenForm: true
        };
    }
};
</script>

<style>
</style>
