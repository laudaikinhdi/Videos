<template>
	<Page class="page" v-if="screenForm">
		<ActionBar title="Form" class="action-bar" />
		<StackLayout class="home-panel">
			<Label text="Họ và tên" />
			<Label v-if="errors.name != ''" :text="errors.name" class="text-danger" />
			<TextField v-model.trim="name" hint="Họ và tên" />
			<Label text="Email" />
			<Label v-if="errors.email != ''" :text="errors.email" class="text-danger" />
			<TextField v-model.trim="email" hint="Email" />
			<Button class="btn btn-primary" text="Xác nhận" @tap="go" />
		</StackLayout>
	</Page>
</template>
<script>
import Country from "./Country";
export default {
    methods: {
        go() {
            // this.screenForm = false;
            // this.countries.push({
            //     name: this.name,
            //     email: this.email
            // });
            let dataNew = { name: this.name, email: this.email };
            this.countries = [...this.countries, dataNew];
            this.$navigateTo(Country, {
                context: { propsData: { countries: this.countries } }
            });
        },
        checkMail(value) {
            let rex = /^[a-z]+@onetech.vn/;
            return rex.test(value);
        }
    },

    data() {
        return {
            email: "",
            name: "",
            screenForm: true,
            errors: {
                name: "",
                email: ""
            },
            countries: [
                {
                    name: "Tân",
                    email: "tanmnt@onetech.vn",
                    birthday: "1996/02/17"
                },
                {
                    name: "Duy",
                    email: "duy@onetech.vn",
                    birthday: "1995/02/1/08"
                },
                {
                    name: "Huy",
                    email: "huy@onetech.vn",
                    birthday: "1997/02/19"
                },
                {
                    name: "Bảo",
                    email: "bao@onetech.vn",
                    birthday: "1998/02/07"
                },
                {
                    name: "Hùng",
                    email: "hung@onetech.vn",
                    birthday: "1999/02/27"
                },
                {
                    name: "Tâm",
                    email: "tam@onetech.vn",
                    birthday: "2000/02/17"
                }
            ]
        };
    },
    watch: {
        name(val) {
            if (val.length == 0) {
                this.errors.name = "Họ và tên không được để trống!";
            } else {
                this.errors.name = "";
            }
        },
        email(val) {
            let check = this.checkMail(val);
            if (!check) {
                this.errors.email = "Email không hợp lệ!";
            } else {
                this.errors.email = "";
            }
        }
    },
    components: {
        appCountry: Country
    }
};
</script>

<style scoped>
	.home-panel {
		vertical-align: center;
		font-size: 20;
		margin: 15;
	}

	.description-label {
		margin-bottom: 15;
	}
</style>
